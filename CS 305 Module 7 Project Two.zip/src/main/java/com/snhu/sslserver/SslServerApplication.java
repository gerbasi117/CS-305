package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.security.MessageDigest;

@SpringBootApplication
public class SslServerApplication {

	public static String calculateSHA256(String data) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data.getBytes("UTF-8"));
        StringBuilder hexString = new StringBuilder();

        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(SslServerApplication.class, args);
        
        // Example data for checksum verification
        String data = "Hello World Check Sum!";
        String checksum = calculateSHA256(data);
        System.out.println("SHA-256 Checksum: " + checksum);
    }
}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";